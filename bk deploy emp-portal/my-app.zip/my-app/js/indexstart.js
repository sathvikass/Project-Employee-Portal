$(document).ready(function() {
    
  alert("Welcome to Employee Portal!!!");  
    
});